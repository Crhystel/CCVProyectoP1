﻿using System.ComponentModel.DataAnnotations;

namespace CCVProyecto1._1.Models
{
    public class Administrador: Usuario
    {
        
    }
}
